TOPIC 9b: Write a computer program with good GUI to play Let It Ride.

A program by:

	Leo McCarthy-Kennedy	
	Gurpiar Brar 		
	Adam Khaddaj 		

Using image resources from:

	http://acbl.mybigcommerce.com/52-playing-cards/

Check videos for setup instructions and gameplay.

To see a list of rank calculations performed by the algorithm used in our program, look at the CALC.txt file.

It is recommended that you use Google Chrome to run the application as it may not run on other browsers.